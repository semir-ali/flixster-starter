export interface Movie {
  id: number;
  title: string;
  poster: string;
  backdrop: string;
  rating: number;
  releaseDate: string;
  runtime: number;
  genres: string[];
  overview: string;
  trailerKey: string;
  aiRecommendation: string;
}

export const MOVIES: Movie[] = [
  {
    id: 1,
    title: "Dune: Part Two",
    poster: "https://image.tmdb.org/t/p/w500/8b8R8l88Qje9dn9OE8PY05Nxl1X.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/xOMo8BRK7PfcJv9JCnx7s5hj0PX.jpg",
    rating: 8.4,
    releaseDate: "2024-03-01",
    runtime: 166,
    genres: ["Science Fiction", "Adventure", "Drama"],
    overview: "Follow the mythic journey of Paul Atreides as he unites with Chani and the Fremen while on a warpath of revenge against the conspirators who destroyed his family.",
    trailerKey: "Way9Dexny3w",
    aiRecommendation: "A stunning visual epic that delivers on both spectacle and substance. Perfect for fans of sprawling world-building and complex political intrigue."
  },
  {
    id: 2,
    title: "Oppenheimer",
    poster: "https://image.tmdb.org/t/p/w500/8Gxv8gSFCU0XGDykEGv7zR1n2ua.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/rLb2cwF3Pazuxaj0sRXQ037tGI1.jpg",
    rating: 8.1,
    releaseDate: "2023-07-21",
    runtime: 180,
    genres: ["Drama", "History", "Thriller"],
    overview: "The story of American scientist J. Robert Oppenheimer and his role in the development of the atomic bomb during World War II.",
    trailerKey: "uYPbbksJxIg",
    aiRecommendation: "Christopher Nolan's most ambitious film yet. The non-linear structure rewards patient viewers with one of cinema's most haunting final acts."
  },
  {
    id: 3,
    title: "Poor Things",
    poster: "https://image.tmdb.org/t/p/w500/kCGlIMHnOm8JPXq3rXM6c5wMxcT.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/bQXAqRx2Fgc46uCVWgoPz5L5Dtr.jpg",
    rating: 8.0,
    releaseDate: "2023-12-08",
    runtime: 141,
    genres: ["Comedy", "Drama", "Romance", "Science Fiction"],
    overview: "Brought back to life by an unorthodox scientist, a young woman runs off with a lawyer on a whirlwind adventure across the continents.",
    trailerKey: "RlbR5N6veqw",
    aiRecommendation: "A fearlessly original feminist odyssey drenched in surrealist visuals. Emma Stone delivers a career-defining performance that demands to be seen."
  },
  {
    id: 4,
    title: "The Zone of Interest",
    poster: "https://image.tmdb.org/t/p/w500/hUu9zyZmDd5VECNguxMLRScSR6L.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/xBfM6GWMtGLUg5EjBiknm6BVkZO.jpg",
    rating: 7.5,
    releaseDate: "2023-12-15",
    runtime: 105,
    genres: ["Drama", "History", "War"],
    overview: "The commandant of Auschwitz, Rudolf Höss, and his wife Hedwig strive to build a dream life for their family in a house and garden next to the camp.",
    trailerKey: "HrmPMedaM-o",
    aiRecommendation: "Profoundly unsettling in its banality. Glazer's restraint creates horror through absence — what you don't see becomes more devastating than what you do."
  },
  {
    id: 5,
    title: "Killers of the Flower Moon",
    poster: "https://image.tmdb.org/t/p/w500/dB6Sea7jMCRBcTQYyHPz3bfNJuY.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/1X7vow16X7CnCoexXh4H4F2yDJv.jpg",
    rating: 7.6,
    releaseDate: "2023-10-20",
    runtime: 206,
    genres: ["Crime", "Drama", "History", "Western"],
    overview: "When oil is discovered in 1920s Oklahoma under Osage Nation land, the Osage people are murdered one by one — until the FBI steps in to unravel the mystery.",
    trailerKey: "EP34Yoxs3FQ",
    aiRecommendation: "Scorsese at his most mature and morally complex. A sweeping American tragedy that reexamines the nation's founding sins with unflinching clarity."
  },
  {
    id: 6,
    title: "Past Lives",
    poster: "https://image.tmdb.org/t/p/w500/k3waqVXiZ6OERQqtM1E22lEBQGT.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/uBRpPFcYAYLM75BoR7OdBSHEIQL.jpg",
    rating: 7.9,
    releaseDate: "2023-06-02",
    runtime: 106,
    genres: ["Drama", "Romance"],
    overview: "Nora and Hae Sung, two deeply connected childhood friends, are separated when Nora's family emigrates from South Korea. Twenty years later, they are reunited in New York for one fateful week.",
    trailerKey: "kA7-XUkM5Ro",
    aiRecommendation: "A quietly devastating meditation on love, identity, and the roads not taken. Celine Song's debut is one of the most emotionally precise films in years."
  },
  {
    id: 7,
    title: "Wonka",
    poster: "https://image.tmdb.org/t/p/w500/qhb1qOilapbapxWQn9jtRkgaevJ.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/5LdGr01PGRmrg6Hh3LYPGlmWnEI.jpg",
    rating: 7.1,
    releaseDate: "2023-12-15",
    runtime: 116,
    genres: ["Comedy", "Family", "Fantasy"],
    overview: "With dreams of opening a shop in a city renowned for its chocolate, a young and poor Willy Wonka discovers that the city is run by a cartel of greedy chocolatiers.",
    trailerKey: "otNh9bTjXWg",
    aiRecommendation: "Delightfully whimsical and surprisingly heartfelt. Chalamet brings genuine charm to the iconic role, making this origin story a confection worth savoring."
  },
  {
    id: 8,
    title: "The Holdovers",
    poster: "https://image.tmdb.org/t/p/w500/VHmCMPBMJsHGMmJJOJtYGiLbMf.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/aoiRKWRFNAGW53pBQMtUvRMtRRa.jpg",
    rating: 7.9,
    releaseDate: "2023-11-10",
    runtime: 133,
    genres: ["Comedy", "Drama"],
    overview: "A curmudgeonly teacher at a New England prep school is forced to remain on campus over the holidays with a student who has no place to go.",
    trailerKey: "AhKNBegugJE",
    aiRecommendation: "A wonderfully old-fashioned character study with genuine warmth. Paul Giamatti and Dominic Sessa have extraordinary chemistry in this instant holiday classic."
  },
  {
    id: 9,
    title: "Saltburn",
    poster: "https://image.tmdb.org/t/p/w500/qitHFQFKOvGvWpbHxKPLthNVOWp.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/2OMB0ynKlyIenMJWI2ByTHBCB7K.jpg",
    rating: 7.1,
    releaseDate: "2023-11-22",
    runtime: 131,
    genres: ["Drama", "Mystery", "Thriller"],
    overview: "A student at Oxford University finds himself drawn into the world of a charming and aristocratic classmate, who invites him to his eccentric family's sprawling estate for a summer.",
    trailerKey: "VGSIqwVjg4E",
    aiRecommendation: "Emerald Fennell's dark obsession grows more twisted by the frame. A Merchant Ivory film viewed through a funhouse mirror — seductive, unsettling, unforgettable."
  },
  {
    id: 10,
    title: "Society of the Snow",
    poster: "https://image.tmdb.org/t/p/w500/2e858MSd3qf3XOuXyN6RPhNwYKO.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/k3SHqRPxpJZlUt2C2n1zPaS02YU.jpg",
    rating: 8.0,
    releaseDate: "2024-01-04",
    runtime: 144,
    genres: ["Drama", "History", "Survival"],
    overview: "In October 1972, a Uruguayan rugby team's plane crashes in the Andes. The 29 survivors must endure weeks in freezing conditions, facing the impossible to stay alive.",
    trailerKey: "aw5ERqFf-1o",
    aiRecommendation: "A visceral survival story told with rare humanity. J.A. Bayona renders the unimaginable with breathtaking scope and deep emotional intelligence."
  },
  {
    id: 11,
    title: "Cabrini",
    poster: "https://image.tmdb.org/t/p/w500/drhFIQpqBuFY0BF4J49bxLmWaZe.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/x1GFCBrHCBtPjKtGTUyWE1GAQCE.jpg",
    rating: 7.2,
    releaseDate: "2024-03-08",
    runtime: 143,
    genres: ["Biography", "Drama", "History"],
    overview: "The story of Italian immigrant Francesca Cabrini, who arrived in New York City in 1889 and persuaded the Pope and President to help her build an empire of hope for the most vulnerable.",
    trailerKey: "UgEmkxpFcJA",
    aiRecommendation: "An inspiring and beautifully photographed portrait of one of history's most determined reformers. Cristiana Dell'Anna commands the screen with quiet authority."
  },
  {
    id: 12,
    title: "Argylle",
    poster: "https://image.tmdb.org/t/p/w500/95er6bwnaFBQ2THAnbr4bHmMQZZ.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/lBhbV2MfM2v3fohzkkAnwuoCjhL.jpg",
    rating: 6.3,
    releaseDate: "2024-02-02",
    runtime: 139,
    genres: ["Action", "Adventure", "Comedy"],
    overview: "A reclusive author who writes espionage novels about a secret agent becomes embroiled in a real-world spy thriller.",
    trailerKey: "eTp3YRiJXHI",
    aiRecommendation: "Mathew Vaughn unleashes his maximalist instincts in this kaleidoscopic spy romp. Don't think too hard — just embrace the delicious absurdity."
  },
  {
    id: 13,
    title: "Madame Web",
    poster: "https://image.tmdb.org/t/p/w500/rjkmN1dniUHVYAtwuV3Tji7FsDO.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/xRl3SBnZCo0ysmFb8HlX1vKJGUU.jpg",
    rating: 5.2,
    releaseDate: "2024-02-14",
    runtime: 116,
    genres: ["Action", "Adventure", "Sci-Fi"],
    overview: "A paramedic in New York City starts to have visions of the future when she faces a mysterious villain.",
    trailerKey: "aSiDu3Ywi8E",
    aiRecommendation: "A baffling entry in the Sony Spider-Verse that's entertaining for all the wrong reasons. A rare viewing experience that becomes better as it gets worse."
  },
  {
    id: 14,
    title: "Drive-Away Dolls",
    poster: "https://image.tmdb.org/t/p/w500/lbQsUVkUn4dGN2JQWJT2jVCKRDP.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/fPCVRVpVfRoUdJHfqLCnKqxTNc5.jpg",
    rating: 6.3,
    releaseDate: "2024-02-23",
    runtime: 84,
    genres: ["Comedy", "Crime", "Thriller"],
    overview: "After a bad breakup, Jamie and her cautious friend Marian embark on an impromptu road trip to Tallahassee, but things quickly go awry when they cross paths with criminals.",
    trailerKey: "vxA22VFwLNw",
    aiRecommendation: "Ethan Coen's solo debut is a breezy, sun-dappled road trip comedy with a screwball heart. Short, snappy, and completely unpretentious."
  },
  {
    id: 15,
    title: "Imaginary",
    poster: "https://image.tmdb.org/t/p/w500/pX0M9l1dEXLV0bKnVB9RQKQV0lI.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/2zNBfn4ylp0rqG3S3rYVrqXz1RI.jpg",
    rating: 5.3,
    releaseDate: "2024-03-08",
    runtime: 104,
    genres: ["Horror", "Thriller"],
    overview: "A woman returns to her childhood home to discover that her youngest stepdaughter has formed a disturbing attachment to a stuffed bear left behind from her own childhood.",
    trailerKey: "sNrLOK8tR7I",
    aiRecommendation: "A serviceable horror entry that leans hard into childhood terror. Won't reinvent the genre, but delivers enough genuine scares for a solid Friday night watch."
  },
  {
    id: 16,
    title: "Ghostbusters: Frozen Empire",
    poster: "https://image.tmdb.org/t/p/w500/sg4BHPBXBFXV8Bgj40YEZZFfLQR.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/z58OQZM9E6cBpHNQlB8HG6QQRCA.jpg",
    rating: 6.9,
    releaseDate: "2024-03-22",
    runtime: 115,
    genres: ["Adventure", "Comedy", "Fantasy"],
    overview: "The Spengler family returns to where it all started — the iconic New York City firehouse — to team up with the original Ghostbusters to confront a terrifying ancient evil.",
    trailerKey: "pZexk_uFHiU",
    aiRecommendation: "Earnest and affectionate, this sequel delivers exactly what fans want: gadgets, ghosts, and the warmth of beloved characters reunited."
  },
  {
    id: 17,
    title: "Kung Fu Panda 4",
    poster: "https://image.tmdb.org/t/p/w500/kDp1vUBnMpe8ak4rjgl3cLELqjU.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/3tzMCLOlQhNXg7RPKbJjJSM5DGW.jpg",
    rating: 6.8,
    releaseDate: "2024-03-08",
    runtime: 94,
    genres: ["Action", "Adventure", "Animation", "Comedy", "Family"],
    overview: "Po is gearing up to become the Spiritual Leader of the Valley of Peace, but also needs someone to take his place as Dragon Warrior.",
    trailerKey: "3Q7aqe-F_TM",
    aiRecommendation: "Zhen the fox steals every scene in this charming if formulaic fourth chapter. The visuals remain stunning and Jack Black's enthusiasm is endlessly infectious."
  },
  {
    id: 18,
    title: "Monkey Man",
    poster: "https://image.tmdb.org/t/p/w500/fd7jnhpMnmKSBiCaHkHhANwc7Cp.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/5kkw5RT0gDkw0WDSEi3MdH16G62.jpg",
    rating: 7.2,
    releaseDate: "2024-04-05",
    runtime: 122,
    genres: ["Action", "Thriller"],
    overview: "A young man emerges from India's underground fight clubs on a mission of vengeance against the corrupt leaders who murdered his mother and continue to exploit the poor.",
    trailerKey: "1h0VGzRMc1s",
    aiRecommendation: "Dev Patel unleashes pure kinetic fury in his directorial debut. A visceral, mythology-infused revenge thriller that establishes him as a major filmmaking talent."
  },
  {
    id: 19,
    title: "Civil War",
    poster: "https://image.tmdb.org/t/p/w500/nVRyd8hlg0ZLxBn9RaI7mUMQLnz.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/sh7Rg8Er3tFcN9BpKIPOMvALgZd.jpg",
    rating: 7.2,
    releaseDate: "2024-04-12",
    runtime: 109,
    genres: ["Action", "Drama", "War", "Thriller"],
    overview: "A journey across a dystopian future America, following a team of military-embedded journalists as they race against time to reach Washington, D.C. before White House soldiers do.",
    trailerKey: "GF3Wy7zC3fU",
    aiRecommendation: "Alex Garland's most urgent film. A nerve-shredding road movie and a meditation on the role of journalists in conflict — ruthlessly relevant for our current moment."
  },
  {
    id: 20,
    title: "Godzilla x Kong: The New Empire",
    poster: "https://image.tmdb.org/t/p/w500/z1p34vh7dEOnLDmyCrlUVLuoDzd.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/xRlyrFpqnMSmkwqLuV3jrO4tSqY.jpg",
    rating: 6.7,
    releaseDate: "2024-03-29",
    runtime: 115,
    genres: ["Action", "Adventure", "Science Fiction"],
    overview: "Two ancient titans — Godzilla and Kong — forge an uneasy alliance when an immense uncharted realm is discovered within our world.",
    trailerKey: "pVxOVlm_lE8",
    aiRecommendation: "Maximalist monster mayhem delivered with spectacular confidence. Turn your brain off, turn the volume up, and enjoy cinema's most spectacular WWE match."
  },
  {
    id: 21,
    title: "Immaculate",
    poster: "https://image.tmdb.org/t/p/w500/fdZpvODTX5wwT8OWFXvKFMtJPQs.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/uMOnNMJKLkxnkQqQVZfPEZZpNub.jpg",
    rating: 6.1,
    releaseDate: "2024-03-22",
    runtime: 89,
    genres: ["Horror", "Mystery", "Thriller"],
    overview: "Cecilia, a woman of fierce devotion, goes to work at an idyllic Italian convent. Her warm welcome quickly devolves into a nightmare as it becomes clear the convent harbors a sinister secret.",
    trailerKey: "hnSRWGhOzs0",
    aiRecommendation: "Sydney Sweeney commits fully to this gothic horror with an electrifying final act that justifies the entire runtime. Bold, messy, and genuinely disturbing."
  },
  {
    id: 22,
    title: "Late Night with the Devil",
    poster: "https://image.tmdb.org/t/p/w500/mQ5DNJnKaJqjN0MfxWRxCLzJpAO.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/4u7hHHgHp2ZiZzJpwkzWw9SJKpV.jpg",
    rating: 7.0,
    releaseDate: "2024-03-22",
    runtime: 93,
    genres: ["Horror", "Mystery", "Thriller"],
    overview: "A live television broadcast in 1977 goes horribly wrong, unleashing evil into the nation's living rooms.",
    trailerKey: "L-3WPmS7YaU",
    aiRecommendation: "A crackling slow-burn that weaponizes found footage within a meticulous period recreation. The final 20 minutes deliver genuine shock-and-awe horror."
  },
  {
    id: 23,
    title: "The Fall Guy",
    poster: "https://image.tmdb.org/t/p/w500/tSz1qsmSJon0rqjHBxXZmrotuse.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/H5HjE7Xb9N09rbWn1zBfxgI8uz.jpg",
    rating: 7.2,
    releaseDate: "2024-05-03",
    runtime: 126,
    genres: ["Action", "Comedy"],
    overview: "A stuntman, fresh off an injury that sidelined him, falls back into action when the star of a mega-budget studio movie goes missing.",
    trailerKey: "MYMiCqGTREM",
    aiRecommendation: "A love letter to stunt performers wrapped in a charming rom-com. Ryan Gosling and Emily Blunt have chemistry to spare in this crowd-pleasing summer treat."
  },
  {
    id: 24,
    title: "Kingdom of the Planet of the Apes",
    poster: "https://image.tmdb.org/t/p/w500/gKkl37BQuKTanygYQG1pyYgLVgf.jpg",
    backdrop: "https://image.tmdb.org/t/p/original/fqv8v6AycXKXdbrfNIOuIpkjp1D.jpg",
    rating: 6.8,
    releaseDate: "2024-05-10",
    runtime: 145,
    genres: ["Adventure", "Science Fiction"],
    overview: "Many generations in the future following Caesar's reign, apes are now the dominant species and live harmoniously while humans have been reduced to living in the shadows.",
    trailerKey: "nrGFZOLFAl0",
    aiRecommendation: "A thoughtful and surprisingly moving reboot. Wes Ball constructs a world that rewards Caesar's legacy while forging a new mythology worth following."
  },
];

export const SECTIONS = [
  { id: "now-playing", title: "Now Playing", movieIds: [1, 2, 3, 18, 19, 23, 24, 20] },
  { id: "top-rated", title: "Top Rated", movieIds: [2, 1, 10, 6, 8, 5, 3, 9] },
  { id: "similar-to-dune", title: "Because You Watched Dune", movieIds: [24, 18, 19, 20, 23, 17, 7, 16] },
  { id: "action", title: "Action & Adventure", movieIds: [18, 19, 20, 23, 24, 17, 12, 16] },
  { id: "drama", title: "Drama", movieIds: [2, 5, 6, 8, 10, 3, 4, 11] },
  { id: "horror", title: "Horror & Thriller", movieIds: [9, 22, 21, 15, 4, 13, 14, 19] },
  { id: "comedy", title: "Comedy", movieIds: [3, 7, 8, 14, 16, 17, 23, 12] },
  { id: "trending", title: "Trending This Week", movieIds: [1, 18, 23, 3, 19, 9, 22, 24] },
];
