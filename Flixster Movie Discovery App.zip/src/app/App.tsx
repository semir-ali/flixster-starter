import { useState } from "react";
import { Film, Search, Heart, CheckCircle, Menu, X } from "lucide-react";
import { HomePage } from "./components/HomePage";
import { SearchPage } from "./components/SearchPage";
import { CollectionPage } from "./components/CollectionPage";
import { MovieModal } from "./components/MovieModal";
import type { Movie } from "./mockData";

type Page = "home" | "search" | "favorites" | "watched";

const NAV_ITEMS: { id: Page; label: string; icon: React.ReactNode }[] = [
  { id: "home", label: "Home", icon: <Film size={16} /> },
  { id: "search", label: "Search", icon: <Search size={16} /> },
  { id: "favorites", label: "Favorites", icon: <Heart size={16} /> },
  { id: "watched", label: "Watched", icon: <CheckCircle size={16} /> },
];

export default function App() {
  const [page, setPage] = useState<Page>("home");
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [favorites, setFavorites] = useState<Set<number>>(new Set());
  const [watched, setWatched] = useState<Set<number>>(new Set());
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleFavorite = (id: number) => {
    setFavorites((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const toggleWatched = (id: number) => {
    setWatched((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  };

  const navigate = (p: Page) => {
    setPage(p);
    setMobileMenuOpen(false);
  };

  const sharedProps = {
    favorites,
    watched,
    onToggleFavorite: toggleFavorite,
    onToggleWatched: toggleWatched,
    onMovieClick: setSelectedMovie,
  };

  return (
    <div style={{ minHeight: "100vh", background: "#121212", fontFamily: "'Inter', sans-serif" }}>
      {/* Header / Nav */}
      <header
        style={{
          position: "sticky",
          top: 0,
          zIndex: 100,
          background: "rgba(18,18,18,0.95)",
          backdropFilter: "blur(12px)",
          borderBottom: "1px solid rgba(255,255,255,0.06)",
        }}
      >
        <div
          style={{
            maxWidth: "1400px",
            margin: "0 auto",
            padding: "0 1.5rem",
            height: "3.75rem",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          {/* Logo */}
          <button
            onClick={() => navigate("home")}
            style={{
              background: "none",
              border: "none",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
            }}
          >
            <div
              style={{
                background: "#e50914",
                borderRadius: "0.375rem",
                width: "2rem",
                height: "2rem",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Film size={16} color="white" />
            </div>
            <span style={{ color: "white", fontWeight: 900, fontSize: "1.3rem", letterSpacing: "-0.02em" }}>
              Flix<span style={{ color: "#e50914" }}>ster</span>
            </span>
          </button>

          {/* Desktop nav */}
          <nav style={{ display: "flex", alignItems: "center", gap: "0.25rem" }} className="hidden-mobile">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.4rem",
                  padding: "0.45rem 0.875rem",
                  borderRadius: "0.4rem",
                  border: "none",
                  background: page === item.id ? "rgba(229,9,20,0.12)" : "transparent",
                  color: page === item.id ? "#e50914" : "#d1d5db",
                  fontSize: "0.875rem",
                  fontWeight: page === item.id ? 600 : 400,
                  cursor: "pointer",
                  transition: "all 0.15s",
                }}
              >
                {item.icon}
                {item.label}
                {item.id === "favorites" && favorites.size > 0 && (
                  <span
                    style={{
                      background: "#e50914",
                      color: "white",
                      borderRadius: "50%",
                      width: "1.1rem",
                      height: "1.1rem",
                      fontSize: "0.65rem",
                      fontWeight: 700,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {favorites.size}
                  </span>
                )}
                {item.id === "watched" && watched.size > 0 && (
                  <span
                    style={{
                      background: "#16a34a",
                      color: "white",
                      borderRadius: "50%",
                      width: "1.1rem",
                      height: "1.1rem",
                      fontSize: "0.65rem",
                      fontWeight: 700,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                    }}
                  >
                    {watched.size}
                  </span>
                )}
              </button>
            ))}
          </nav>

          {/* Mobile menu toggle */}
          <button
            className="show-mobile"
            onClick={() => setMobileMenuOpen((v) => !v)}
            style={{ background: "none", border: "none", color: "white", cursor: "pointer", display: "none" }}
          >
            {mobileMenuOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>

        {/* Mobile dropdown */}
        {mobileMenuOpen && (
          <div
            style={{
              background: "#1e1e1e",
              borderTop: "1px solid rgba(255,255,255,0.08)",
              padding: "0.5rem 1rem 1rem",
              display: "flex",
              flexDirection: "column",
              gap: "0.25rem",
            }}
          >
            {NAV_ITEMS.map((item) => (
              <button
                key={item.id}
                onClick={() => navigate(item.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: "0.6rem",
                  padding: "0.7rem 0.875rem",
                  borderRadius: "0.4rem",
                  border: "none",
                  background: page === item.id ? "rgba(229,9,20,0.12)" : "transparent",
                  color: page === item.id ? "#e50914" : "#d1d5db",
                  fontSize: "0.9rem",
                  fontWeight: page === item.id ? 600 : 400,
                  cursor: "pointer",
                  textAlign: "left",
                }}
              >
                {item.icon}
                {item.label}
              </button>
            ))}
          </div>
        )}
      </header>

      {/* Main content */}
      <main style={{ maxWidth: "1400px", margin: "0 auto", padding: "1.75rem 1.5rem 3rem" }}>
        {page === "home" && <HomePage {...sharedProps} />}
        {page === "search" && <SearchPage {...sharedProps} />}
        {page === "favorites" && <CollectionPage mode="favorites" {...sharedProps} />}
        {page === "watched" && <CollectionPage mode="watched" {...sharedProps} />}
      </main>

      {/* Movie modal */}
      {selectedMovie && (
        <MovieModal
          movie={selectedMovie}
          isFavorite={favorites.has(selectedMovie.id)}
          isWatched={watched.has(selectedMovie.id)}
          onToggleFavorite={toggleFavorite}
          onToggleWatched={toggleWatched}
          onClose={() => setSelectedMovie(null)}
        />
      )}

      <style>{`
        @media (max-width: 640px) {
          .hidden-mobile { display: none !important; }
          .show-mobile { display: flex !important; }
        }
        ::-webkit-scrollbar { width: 0; height: 0; }
        * { scrollbar-width: none; }
      `}</style>
    </div>
  );
}
