import { useState, useMemo } from "react";
import { Search, ChevronDown } from "lucide-react";
import { MovieCard } from "./MovieCard";
import { MOVIES } from "../mockData";
import type { Movie } from "../mockData";

interface SearchPageProps {
  favorites: Set<number>;
  watched: Set<number>;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onMovieClick: (movie: Movie) => void;
}

type SortKey = "title" | "releaseDate" | "voteAverage";

const SORT_OPTIONS: { label: string; value: SortKey }[] = [
  { label: "Title", value: "title" },
  { label: "Release Date", value: "releaseDate" },
  { label: "Vote Average", value: "voteAverage" },
];

const PAGE_SIZE = 12;

export function SearchPage({ favorites, watched, onToggleFavorite, onToggleWatched, onMovieClick }: SearchPageProps) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("voteAverage");
  const [page, setPage] = useState(1);
  const [sortOpen, setSortOpen] = useState(false);

  const filtered = useMemo(() => {
    let results = [...MOVIES];
    if (query.trim()) {
      const q = query.toLowerCase();
      results = results.filter(
        (m) => m.title.toLowerCase().includes(q) || m.genres.some((g) => g.toLowerCase().includes(q))
      );
    }
    results.sort((a, b) => {
      if (sort === "title") return a.title.localeCompare(b.title);
      if (sort === "releaseDate") return b.releaseDate.localeCompare(a.releaseDate);
      return b.rating - a.rating;
    });
    return results;
  }, [query, sort]);

  const visible = filtered.slice(0, page * PAGE_SIZE);
  const hasMore = visible.length < filtered.length;

  const selectedLabel = SORT_OPTIONS.find((o) => o.value === sort)?.label ?? "Sort";

  return (
    <div>
      {/* Search controls */}
      <div style={{ display: "flex", gap: "0.75rem", marginBottom: "1.75rem", alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ position: "relative", flex: 1, minWidth: "220px" }}>
          <Search size={16} color="#9ca3af" style={{ position: "absolute", left: "0.875rem", top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }} />
          <input
            type="text"
            placeholder="Search movies, genres…"
            value={query}
            onChange={(e) => { setQuery(e.target.value); setPage(1); }}
            style={{
              width: "100%",
              background: "#2a2a2a",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "0.5rem",
              padding: "0.7rem 1rem 0.7rem 2.5rem",
              color: "white",
              fontSize: "0.875rem",
              outline: "none",
              boxSizing: "border-box",
            }}
          />
        </div>

        {/* Sort dropdown */}
        <div style={{ position: "relative" }}>
          <button
            onClick={() => setSortOpen((v) => !v)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: "0.5rem",
              background: "#2a2a2a",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: "0.5rem",
              padding: "0.7rem 1rem",
              color: "white",
              fontSize: "0.875rem",
              cursor: "pointer",
              whiteSpace: "nowrap",
            }}
          >
            Sort: {selectedLabel}
            <ChevronDown size={14} style={{ transform: sortOpen ? "rotate(180deg)" : "rotate(0)", transition: "transform 0.15s" }} />
          </button>
          {sortOpen && (
            <div
              style={{
                position: "absolute",
                top: "calc(100% + 0.375rem)",
                right: 0,
                background: "#2a2a2a",
                border: "1px solid rgba(255,255,255,0.12)",
                borderRadius: "0.5rem",
                overflow: "hidden",
                zIndex: 50,
                minWidth: "170px",
                boxShadow: "0 8px 24px rgba(0,0,0,0.6)",
              }}
            >
              {SORT_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => { setSort(opt.value); setSortOpen(false); setPage(1); }}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    padding: "0.65rem 1rem",
                    background: sort === opt.value ? "rgba(229,9,20,0.15)" : "transparent",
                    color: sort === opt.value ? "#f87171" : "white",
                    border: "none",
                    fontSize: "0.875rem",
                    cursor: "pointer",
                    transition: "background 0.1s",
                  }}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Result count */}
      <p style={{ color: "#9ca3af", fontSize: "0.8rem", marginBottom: "1rem" }}>
        {filtered.length} {filtered.length === 1 ? "movie" : "movies"} found
      </p>

      {/* Grid */}
      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))",
          gap: "1rem",
          marginBottom: "2rem",
        }}
      >
        {visible.map((movie) => (
          <MovieCard
            key={movie.id}
            movie={movie}
            isFavorite={favorites.has(movie.id)}
            isWatched={watched.has(movie.id)}
            onToggleFavorite={onToggleFavorite}
            onToggleWatched={onToggleWatched}
            onClick={onMovieClick}
          />
        ))}
      </div>

      {filtered.length === 0 && (
        <div style={{ textAlign: "center", color: "#9ca3af", padding: "3rem 0" }}>
          <Search size={40} color="#4b5563" style={{ marginBottom: "0.75rem" }} />
          <p>No movies match your search.</p>
        </div>
      )}

      {hasMore && (
        <div style={{ textAlign: "center", paddingBottom: "1.5rem" }}>
          <button
            onClick={() => setPage((p) => p + 1)}
            style={{
              background: "transparent",
              border: "1.5px solid rgba(255,255,255,0.25)",
              color: "white",
              borderRadius: "2rem",
              padding: "0.65rem 2rem",
              fontSize: "0.875rem",
              fontWeight: 600,
              cursor: "pointer",
              transition: "all 0.15s",
            }}
            onMouseEnter={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "#e50914";
              (e.currentTarget as HTMLButtonElement).style.color = "#e50914";
            }}
            onMouseLeave={(e) => {
              (e.currentTarget as HTMLButtonElement).style.borderColor = "rgba(255,255,255,0.25)";
              (e.currentTarget as HTMLButtonElement).style.color = "white";
            }}
          >
            Load More ({filtered.length - visible.length} remaining)
          </button>
        </div>
      )}
    </div>
  );
}
