import { Heart, CheckCircle } from "lucide-react";
import { MovieCard } from "./MovieCard";
import { MOVIES } from "../mockData";
import type { Movie } from "../mockData";

interface CollectionPageProps {
  mode: "favorites" | "watched";
  favorites: Set<number>;
  watched: Set<number>;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onMovieClick: (movie: Movie) => void;
}

export function CollectionPage({ mode, favorites, watched, onToggleFavorite, onToggleWatched, onMovieClick }: CollectionPageProps) {
  const ids = mode === "favorites" ? favorites : watched;
  const movies = MOVIES.filter((m) => ids.has(m.id));

  const isEmpty = movies.length === 0;

  return (
    <div>
      <h2 style={{ color: "white", fontWeight: 800, fontSize: "1.5rem", marginBottom: "1.5rem" }}>
        {mode === "favorites" ? "My Favorites" : "Watched"}
      </h2>

      {isEmpty ? (
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            justifyContent: "center",
            padding: "5rem 2rem",
            textAlign: "center",
          }}
        >
          {mode === "favorites" ? (
            <Heart size={52} color="#4b5563" style={{ marginBottom: "1rem" }} />
          ) : (
            <CheckCircle size={52} color="#4b5563" style={{ marginBottom: "1rem" }} />
          )}
          <p style={{ color: "#9ca3af", fontSize: "1rem", marginBottom: "0.4rem" }}>
            {mode === "favorites" ? "No favorites yet" : "Nothing watched yet"}
          </p>
          <p style={{ color: "#6b7280", fontSize: "0.875rem" }}>
            {mode === "favorites"
              ? "Hover over any movie card and click ❤️ to add it here."
              : "Hover over any movie card and click ✓ to mark it as watched."}
          </p>
        </div>
      ) : (
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(150px, 1fr))",
            gap: "1rem",
          }}
        >
          {movies.map((movie) => (
            <MovieCard
              key={movie.id}
              movie={movie}
              isFavorite={favorites.has(movie.id)}
              isWatched={watched.has(movie.id)}
              onToggleFavorite={onToggleFavorite}
              onToggleWatched={onToggleWatched}
              onClick={onMovieClick}
            />
          ))}
        </div>
      )}
    </div>
  );
}
