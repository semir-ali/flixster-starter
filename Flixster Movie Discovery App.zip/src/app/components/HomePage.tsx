import { CarouselRow } from "./CarouselRow";
import { MOVIES, SECTIONS } from "../mockData";
import type { Movie } from "../mockData";

interface HomePageProps {
  favorites: Set<number>;
  watched: Set<number>;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onMovieClick: (movie: Movie) => void;
}

export function HomePage({ favorites, watched, onToggleFavorite, onToggleWatched, onMovieClick }: HomePageProps) {
  const movieMap = new Map(MOVIES.map((m) => [m.id, m]));

  const heroMovie = MOVIES[0];

  return (
    <div>
      {/* Hero section */}
      <div
        style={{
          position: "relative",
          width: "100%",
          aspectRatio: "21/8",
          marginBottom: "2.5rem",
          borderRadius: "0.75rem",
          overflow: "hidden",
          cursor: "pointer",
        }}
        onClick={() => onMovieClick(heroMovie)}
      >
        <img
          src={heroMovie.backdrop}
          alt={heroMovie.title}
          style={{ width: "100%", height: "100%", objectFit: "cover" }}
          onError={(e) => {
            (e.target as HTMLImageElement).src = "https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=1400&h=534&fit=crop&auto=format";
          }}
        />
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(to right, rgba(18,18,18,0.9) 0%, rgba(18,18,18,0.5) 50%, transparent 100%)",
          }}
        />
        <div style={{ position: "absolute", bottom: "2rem", left: "2rem", maxWidth: "480px" }}>
          <div
            style={{
              display: "inline-block",
              background: "#e50914",
              color: "white",
              fontSize: "0.7rem",
              fontWeight: 700,
              letterSpacing: "0.08em",
              textTransform: "uppercase",
              padding: "0.2rem 0.6rem",
              borderRadius: "0.25rem",
              marginBottom: "0.6rem",
            }}
          >
            Featured
          </div>
          <h2 style={{ color: "white", fontSize: "2rem", fontWeight: 900, lineHeight: 1.15, marginBottom: "0.6rem" }}>
            {heroMovie.title}
          </h2>
          <p style={{ color: "#d1d5db", fontSize: "0.875rem", lineHeight: 1.6, marginBottom: "1rem" }}>
            {heroMovie.overview.slice(0, 140)}…
          </p>
          <button
            style={{
              background: "#e50914",
              color: "white",
              border: "none",
              borderRadius: "0.375rem",
              padding: "0.625rem 1.5rem",
              fontSize: "0.875rem",
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            More Info
          </button>
        </div>
      </div>

      {/* Carousels */}
      {SECTIONS.map((section) => {
        const sectionMovies = section.movieIds
          .map((id) => movieMap.get(id))
          .filter(Boolean) as Movie[];
        return (
          <CarouselRow
            key={section.id}
            title={section.title}
            movies={sectionMovies}
            favorites={favorites}
            watched={watched}
            onToggleFavorite={onToggleFavorite}
            onToggleWatched={onToggleWatched}
            onMovieClick={onMovieClick}
          />
        );
      })}
    </div>
  );
}
