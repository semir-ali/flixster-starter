import { useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { MovieCard } from "./MovieCard";
import type { Movie } from "../mockData";

interface CarouselRowProps {
  title: string;
  movies: Movie[];
  favorites: Set<number>;
  watched: Set<number>;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onMovieClick: (movie: Movie) => void;
}

export function CarouselRow({ title, movies, favorites, watched, onToggleFavorite, onToggleWatched, onMovieClick }: CarouselRowProps) {
  const scrollRef = useRef<HTMLDivElement>(null);

  const scroll = (dir: "left" | "right") => {
    if (!scrollRef.current) return;
    const amount = scrollRef.current.clientWidth * 0.75;
    scrollRef.current.scrollBy({ left: dir === "right" ? amount : -amount, behavior: "smooth" });
  };

  return (
    <div style={{ marginBottom: "2.25rem" }}>
      <h3 style={{ color: "white", fontWeight: 700, fontSize: "1.1rem", marginBottom: "0.85rem", paddingLeft: "0" }}>{title}</h3>
      <div style={{ position: "relative" }}>
        {/* Left arrow */}
        <button
          onClick={() => scroll("left")}
          style={{
            position: "absolute",
            left: "-1px",
            top: "50%",
            transform: "translateY(-50%)",
            zIndex: 10,
            background: "linear-gradient(to right, rgba(18,18,18,1) 0%, rgba(18,18,18,0.7) 100%)",
            border: "none",
            color: "white",
            cursor: "pointer",
            height: "100%",
            padding: "0 0.75rem",
            display: "flex",
            alignItems: "center",
            borderRadius: "0.25rem",
          }}
        >
          <ChevronLeft size={22} />
        </button>

        {/* Scrollable track */}
        <div
          ref={scrollRef}
          style={{
            display: "flex",
            gap: "0.6rem",
            overflowX: "auto",
            scrollbarWidth: "none",
            paddingBottom: "0.25rem",
          }}
        >
          {movies.map((movie) => (
            <div key={movie.id} style={{ flexShrink: 0, width: "160px" }}>
              <MovieCard
                movie={movie}
                isFavorite={favorites.has(movie.id)}
                isWatched={watched.has(movie.id)}
                onToggleFavorite={onToggleFavorite}
                onToggleWatched={onToggleWatched}
                onClick={onMovieClick}
              />
            </div>
          ))}
        </div>

        {/* Right arrow */}
        <button
          onClick={() => scroll("right")}
          style={{
            position: "absolute",
            right: "-1px",
            top: "50%",
            transform: "translateY(-50%)",
            zIndex: 10,
            background: "linear-gradient(to left, rgba(18,18,18,1) 0%, rgba(18,18,18,0.7) 100%)",
            border: "none",
            color: "white",
            cursor: "pointer",
            height: "100%",
            padding: "0 0.75rem",
            display: "flex",
            alignItems: "center",
            borderRadius: "0.25rem",
          }}
        >
          <ChevronRight size={22} />
        </button>
      </div>
    </div>
  );
}
