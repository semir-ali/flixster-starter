import { useEffect, useRef } from "react";
import { X, Star, Clock, Calendar, Heart, Check, Sparkles } from "lucide-react";
import type { Movie } from "../mockData";

interface MovieModalProps {
  movie: Movie;
  isFavorite: boolean;
  isWatched: boolean;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onClose: () => void;
}

export function MovieModal({ movie, isFavorite, isWatched, onToggleFavorite, onToggleWatched, onClose }: MovieModalProps) {
  const overlayRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleKey);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === overlayRef.current) onClose();
  };

  const runtime = `${Math.floor(movie.runtime / 60)}h ${movie.runtime % 60}m`;
  const releaseYear = new Date(movie.releaseDate).getFullYear();

  return (
    <div
      ref={overlayRef}
      onClick={handleOverlayClick}
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.85)",
        zIndex: 1000,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "1rem",
        backdropFilter: "blur(4px)",
      }}
    >
      <div
        style={{
          background: "#1e1e1e",
          borderRadius: "1rem",
          width: "100%",
          maxWidth: "860px",
          maxHeight: "90vh",
          overflowY: "auto",
          position: "relative",
          boxShadow: "0 24px 80px rgba(0,0,0,0.8)",
          scrollbarWidth: "none",
        }}
      >
        {/* Backdrop */}
        <div style={{ position: "relative", aspectRatio: "16/7", overflow: "hidden", borderRadius: "1rem 1rem 0 0" }}>
          <img
            src={movie.backdrop}
            alt={movie.title}
            style={{ width: "100%", height: "100%", objectFit: "cover" }}
            onError={(e) => {
              (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1536440136628-849c177e76a1?w=860&h=480&fit=crop&auto=format`;
            }}
          />
          <div style={{ position: "absolute", inset: 0, background: "linear-gradient(to top, #1e1e1e 0%, rgba(30,30,30,0.4) 60%, transparent 100%)" }} />

          {/* Close button */}
          <button
            onClick={onClose}
            style={{
              position: "absolute",
              top: "1rem",
              right: "1rem",
              background: "rgba(0,0,0,0.6)",
              border: "1px solid rgba(255,255,255,0.2)",
              borderRadius: "50%",
              width: "2.25rem",
              height: "2.25rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              color: "white",
              backdropFilter: "blur(4px)",
              transition: "background 0.15s",
            }}
          >
            <X size={16} />
          </button>

          {/* Title overlay */}
          <div style={{ position: "absolute", bottom: "1.25rem", left: "1.5rem", right: "1.5rem" }}>
            <h2 style={{ color: "white", fontSize: "1.75rem", fontWeight: 800, lineHeight: 1.2, marginBottom: "0.5rem" }}>{movie.title}</h2>
            <div style={{ display: "flex", alignItems: "center", gap: "1rem", flexWrap: "wrap" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "0.3rem" }}>
                <Star size={14} fill="#facc15" color="#facc15" />
                <span style={{ color: "#facc15", fontWeight: 700, fontSize: "0.9rem" }}>{movie.rating.toFixed(1)}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.3rem", color: "#d1d5db", fontSize: "0.85rem" }}>
                <Clock size={13} />
                <span>{runtime}</span>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "0.3rem", color: "#d1d5db", fontSize: "0.85rem" }}>
                <Calendar size={13} />
                <span>{releaseYear}</span>
              </div>
            </div>
          </div>
        </div>

        {/* Content */}
        <div style={{ padding: "1.25rem 1.5rem 1.75rem" }}>
          {/* Genre tags */}
          <div style={{ display: "flex", flexWrap: "wrap", gap: "0.5rem", marginBottom: "1.25rem" }}>
            {movie.genres.map((g) => (
              <span
                key={g}
                style={{
                  background: "rgba(229,9,20,0.12)",
                  border: "1px solid rgba(229,9,20,0.3)",
                  color: "#f87171",
                  borderRadius: "2rem",
                  padding: "0.2rem 0.75rem",
                  fontSize: "0.75rem",
                  fontWeight: 500,
                }}
              >
                {g}
              </span>
            ))}
          </div>

          {/* Action buttons */}
          <div style={{ display: "flex", gap: "0.75rem", marginBottom: "1.5rem" }}>
            <button
              onClick={() => onToggleFavorite(movie.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.6rem 1.25rem",
                borderRadius: "2rem",
                border: "1.5px solid",
                borderColor: isFavorite ? "#e50914" : "rgba(255,255,255,0.25)",
                background: isFavorite ? "#e50914" : "transparent",
                color: "white",
                fontSize: "0.85rem",
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              <Heart size={15} fill={isFavorite ? "white" : "none"} />
              {isFavorite ? "Favorited" : "Add to Favorites"}
            </button>
            <button
              onClick={() => onToggleWatched(movie.id)}
              style={{
                display: "flex",
                alignItems: "center",
                gap: "0.5rem",
                padding: "0.6rem 1.25rem",
                borderRadius: "2rem",
                border: "1.5px solid",
                borderColor: isWatched ? "#16a34a" : "rgba(255,255,255,0.25)",
                background: isWatched ? "#16a34a" : "transparent",
                color: "white",
                fontSize: "0.85rem",
                fontWeight: 600,
                cursor: "pointer",
                transition: "all 0.15s",
              }}
            >
              <Check size={15} />
              {isWatched ? "Watched" : "Mark as Watched"}
            </button>
          </div>

          {/* Overview */}
          <div style={{ marginBottom: "1.5rem" }}>
            <h4 style={{ color: "white", fontWeight: 700, marginBottom: "0.6rem", fontSize: "0.95rem" }}>Overview</h4>
            <p style={{ color: "#d1d5db", lineHeight: 1.7, fontSize: "0.9rem" }}>{movie.overview}</p>
          </div>

          {/* AI Recommendation */}
          <div
            style={{
              background: "linear-gradient(135deg, rgba(229,9,20,0.08) 0%, rgba(147,51,234,0.08) 100%)",
              border: "1px solid rgba(229,9,20,0.2)",
              borderRadius: "0.75rem",
              padding: "1rem 1.25rem",
              marginBottom: "1.5rem",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: "0.5rem", marginBottom: "0.6rem" }}>
              <Sparkles size={15} color="#e50914" />
              <span style={{ color: "#e50914", fontWeight: 700, fontSize: "0.85rem" }}>AI Recommendation</span>
            </div>
            <p style={{ color: "#e2e8f0", fontStyle: "italic", fontSize: "0.875rem", lineHeight: 1.65 }}>{movie.aiRecommendation}</p>
          </div>

          {/* Trailer */}
          <div>
            <h4 style={{ color: "white", fontWeight: 700, marginBottom: "0.75rem", fontSize: "0.95rem" }}>Trailer</h4>
            <div style={{ borderRadius: "0.625rem", overflow: "hidden", aspectRatio: "16/9" }}>
              <iframe
                src={`https://www.youtube.com/embed/${movie.trailerKey}?rel=0`}
                title={`${movie.title} Trailer`}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                style={{ width: "100%", height: "100%", border: "none" }}
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
