import { useState } from "react";
import { Star, Heart, Check } from "lucide-react";
import type { Movie } from "../mockData";

interface MovieCardProps {
  movie: Movie;
  isFavorite: boolean;
  isWatched: boolean;
  onToggleFavorite: (id: number) => void;
  onToggleWatched: (id: number) => void;
  onClick: (movie: Movie) => void;
}

export function MovieCard({ movie, isFavorite, isWatched, onToggleFavorite, onToggleWatched, onClick }: MovieCardProps) {
  const [hovered, setHovered] = useState(false);

  const year = new Date(movie.releaseDate).getFullYear();

  return (
    <div
      className="relative rounded-lg overflow-hidden cursor-pointer group"
      style={{
        background: "#1e1e1e",
        boxShadow: hovered ? "0 8px 32px rgba(0,0,0,0.7)" : "0 2px 8px rgba(0,0,0,0.4)",
        transform: hovered ? "translateY(-4px) scale(1.02)" : "translateY(0) scale(1)",
        transition: "all 0.25s ease",
      }}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      onClick={() => onClick(movie)}
    >
      <div className="relative" style={{ aspectRatio: "2/3" }}>
        <img
          src={movie.poster}
          alt={movie.title}
          className="w-full h-full object-cover"
          onError={(e) => {
            (e.target as HTMLImageElement).src = `https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=300&h=450&fit=crop&auto=format`;
          }}
        />

        {/* Overlay on hover */}
        <div
          style={{
            position: "absolute",
            inset: 0,
            background: "linear-gradient(to top, rgba(0,0,0,0.9) 0%, rgba(0,0,0,0.3) 50%, transparent 100%)",
            opacity: hovered ? 1 : 0,
            transition: "opacity 0.25s ease",
          }}
        />

        {/* Action buttons */}
        <div
          style={{
            position: "absolute",
            bottom: "0.75rem",
            left: 0,
            right: 0,
            display: "flex",
            justifyContent: "center",
            gap: "0.75rem",
            opacity: hovered ? 1 : 0,
            transform: hovered ? "translateY(0)" : "translateY(8px)",
            transition: "all 0.25s ease",
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button
            onClick={() => onToggleFavorite(movie.id)}
            style={{
              background: isFavorite ? "#e50914" : "rgba(255,255,255,0.15)",
              border: "1.5px solid",
              borderColor: isFavorite ? "#e50914" : "rgba(255,255,255,0.4)",
              borderRadius: "50%",
              width: "2.25rem",
              height: "2.25rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              transition: "all 0.15s ease",
              backdropFilter: "blur(4px)",
            }}
            title="Add to Favorites"
          >
            <Heart size={14} fill={isFavorite ? "white" : "none"} color="white" />
          </button>
          <button
            onClick={() => onToggleWatched(movie.id)}
            style={{
              background: isWatched ? "#16a34a" : "rgba(255,255,255,0.15)",
              border: "1.5px solid",
              borderColor: isWatched ? "#16a34a" : "rgba(255,255,255,0.4)",
              borderRadius: "50%",
              width: "2.25rem",
              height: "2.25rem",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              transition: "all 0.15s ease",
              backdropFilter: "blur(4px)",
            }}
            title="Mark as Watched"
          >
            <Check size={14} color="white" />
          </button>
        </div>
      </div>

      {/* Card info */}
      <div style={{ padding: "0.65rem 0.75rem 0.75rem" }}>
        <div style={{ color: "#fff", fontSize: "0.8rem", fontWeight: 600, lineHeight: 1.3, marginBottom: "0.25rem", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {movie.title}
        </div>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "0.25rem" }}>
            <Star size={11} fill="#facc15" color="#facc15" />
            <span style={{ color: "#facc15", fontSize: "0.72rem", fontWeight: 600 }}>{movie.rating.toFixed(1)}</span>
          </div>
          <span style={{ color: "#9ca3af", fontSize: "0.7rem" }}>{year}</span>
        </div>
      </div>
    </div>
  );
}
