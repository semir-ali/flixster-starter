
  # Flixster Movie Discovery App

  This is a code bundle for Flixster Movie Discovery App. The original project is available at https://www.figma.com/design/AHe2af1KQ9GuZJnKYUoFBb/Flixster-Movie-Discovery-App.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  